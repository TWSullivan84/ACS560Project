﻿using UnityEngine;
using System.Collections;

public class Move : MonoBehaviour {
    public float speed = 6;

	void FixedUpdate() {
        // Check input axes
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");
        GetComponent<Rigidbody2D>().velocity = new Vector2(h, v) * speed;

        // Set animation parameters
        GetComponent<Animator>().SetInteger("X", (int)h);
        GetComponent<Animator>().SetInteger("Y", (int)v);
    }
}
