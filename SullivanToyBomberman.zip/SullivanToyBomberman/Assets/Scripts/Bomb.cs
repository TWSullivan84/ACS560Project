﻿using UnityEngine;
using System.Collections;

public class Bomb : MonoBehaviour {
    //Explosion Prefab
    public GameObject explosionPrefab;

    void OnDestroy()
    {
        Instantiate(explosionPrefab, transform.position, Quaternion.identity);
    }
}
