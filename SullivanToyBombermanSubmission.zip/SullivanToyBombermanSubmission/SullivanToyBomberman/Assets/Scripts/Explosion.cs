﻿using UnityEngine;
using UnityEngine.Networking;
using System;
using System.Text;
using System.Net;
using System.Net.Sockets;

public class Explosion : NetworkBehaviour {

    void OnTriggerEnter2D(Collider2D co)
    {
        if (!co.gameObject.name.Contains("undestroyable"))
        {
            Destroy(co.gameObject);
        }
    }
}
