﻿using UnityEngine;
using System.Collections;
using UnityEngine.Networking;

public class DestroyAfter : NetworkBehaviour {
    public float time = 3;

	// Use this for initialization
	void Start () {
        Destroy(gameObject, time);
	}
	
}
