﻿using UnityEngine;
using System.Collections;

public class Explosion : MonoBehaviour {
    
    void OnTriggerEnter2D(Collider2D co)
    {
        if (!co.gameObject.isStatic)
            Destroy(co.gameObject);
    }
}
