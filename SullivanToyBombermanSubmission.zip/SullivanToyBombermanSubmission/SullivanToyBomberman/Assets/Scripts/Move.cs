﻿using UnityEngine;
using System.Collections;
using UnityEngine.Networking;

public class Move : NetworkBehaviour {
    public float speed = 6;

	void FixedUpdate() {
        if (!isLocalPlayer)
        {
            return;
        }

        // Check input axes
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");
        GetComponent<Rigidbody2D>().velocity = new Vector2(h, v) * speed;

        // Set animation parameters
        GetComponent<Animator>().SetInteger("X", (int)h);
        GetComponent<Animator>().SetInteger("Y", (int)v);
    }

    public override void OnStartLocalPlayer()
    {
        GetComponent<SpriteRenderer>().material.color = Color.green;
    }
}
