﻿using UnityEngine;
using System.Collections;

public class BombDrop : MonoBehaviour {
    public GameObject bombPrefab;

	// Update is called once per frame
	void Update () {
	    if(Input.GetKeyDown(KeyCode.Space))
        {
            Vector2 pos = transform.position;
            Instantiate(bombPrefab, pos, Quaternion.identity);
        }
	}
}
