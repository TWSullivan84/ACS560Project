﻿using UnityEngine;
using System.Collections;
using UnityEngine.Networking;
using System;
using UnityEngine.UI;

public class BombDrop : NetworkBehaviour
{
    public GameObject bombPrefab;
    public static int clientBombCounter;
    public static int serverBombCounter;
    public Text countClientText;
    public Text countServerText;

    public static int ClientBombCounter{
        get{return clientBombCounter;}
        set{}
    }

    public static int ServerBombCounter
    {
        get { return serverBombCounter; }
        set { }
    }

    private void Start()
    {
        clientBombCounter = 0;
        serverBombCounter = 0;
        SetCountText();

    }
    void Update () {
        if (!isLocalPlayer)
        {
            return;
        }
 
	    if(Input.GetKeyDown(KeyCode.Space))
        {
            if (isServer)
            {
                serverBombCounter++;
            }
            else
                CmdIncreaseClientCounter();
            SetCountText();
            CmdRequestSpawn();
            
        }
    }

    [Command]
    void CmdIncreaseClientCounter()
    {
        clientBombCounter++;
    }

    [Command]
    void CmdRequestSpawn()
    {
        Vector2 pos = transform.position;
        NetworkServer.Spawn((GameObject)Instantiate(bombPrefab, pos, Quaternion.identity));
    }

    void SetCountText()
    {
        countClientText.text = "Client:  " + clientBombCounter;
        countServerText.text = "Server: " + serverBombCounter;
    }
}
